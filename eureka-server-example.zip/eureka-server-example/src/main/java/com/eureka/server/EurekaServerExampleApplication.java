package com.eureka.server;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EurekaServerExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(EurekaServerExampleApplication.class, args);
	}

}
